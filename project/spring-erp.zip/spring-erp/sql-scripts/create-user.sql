CREATE USER 'dbstudent'@'localhost' IDENTIFIED BY 'dbstudent';

GRANT ALL PRIVILEGES ON * . * TO 'dbstudent'@'localhost';
